package com.revShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
