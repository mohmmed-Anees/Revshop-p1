package com.revShop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.revShop.entity.Seller;

public interface SellerRepository extends JpaRepository<Seller, Integer>{
	
	
	Seller findByEmail(String email);
}
