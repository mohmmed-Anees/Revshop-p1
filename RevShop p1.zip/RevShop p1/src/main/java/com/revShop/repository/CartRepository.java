package com.revShop.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.revShop.entity.Cart;
@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {
    // Optional custom query to find a specific cart item for a given user and product
    Optional<Cart> findByBuyerandproduct(Integer userId, Integer productId);
}
