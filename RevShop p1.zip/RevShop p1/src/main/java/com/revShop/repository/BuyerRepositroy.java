package com.revShop.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.revShop.entity.Buyer;


public interface BuyerRepositroy extends JpaRepository<Buyer, Integer>{
	
	Optional<Buyer> findByEmail(String email);
	
	Optional<Buyer> findByResetToken(String resetToken);
	
}
