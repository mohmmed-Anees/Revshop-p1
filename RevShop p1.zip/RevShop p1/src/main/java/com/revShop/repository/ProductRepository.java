package com.revShop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.revShop.entity.Products;

public interface ProductRepository extends JpaRepository<Products, Integer>{
	List<Products> findByCategory(String category);
	
	@Query("SELECT DISTINCT p.category FROM Products p WHERE p.category IS NOT NULL")
    List<String> findAllDistinctCategories();
}
