package com.revShop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.revShop.entity.Cart;
import com.revShop.service.CartService;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/addToCart")
    public ResponseEntity<Cart> addProductToCart(
            @RequestParam("BuyerId") Integer userId,
            @RequestParam("ProductId") Integer productId,
            @RequestParam("Quantity") Integer quantity) {
        
        Cart cart = cartService.addProductToCart(userId, productId, quantity);
        return ResponseEntity.ok(cart);
    }
}
