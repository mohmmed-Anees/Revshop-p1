package com.revShop.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.revShop.entity.Products;
import com.revShop.service.ProductService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/home")
public class HomeController {
	
	
	@Autowired
    private ProductService productService;
	
	@Autowired
	private HttpSession session;
    
	@GetMapping
	public ModelAndView viewHomePage(@RequestParam(value = "category", required = false) String category) {

	    List<String> categories = productService.getAllCategories();
	    if (categories == null || categories.isEmpty()) {
	        System.out.println("Categories are empty or null");
	    } else {
	        System.out.println("Categories fetched after login: " + categories);
	    }

	    List<Products> productList;

	    
	    if (category == null || category.isEmpty() || category.equals("All")) {
	        productList = productService.getAllProducts();  
	    } else {
	        productList = productService.getProductsByCategory(category);  
	    }

	    
	    session.setAttribute("categories", categories);
	    session.setAttribute("products", productList);  

	    ModelAndView modelAndView = new ModelAndView("Home");
	    modelAndView.addObject("products", productList);  
	    modelAndView.addObject("selectedCategory", category);  
	    modelAndView.addObject("categories", categories);  

	    return modelAndView;
	}

	
	@GetMapping("/product")
    public ModelAndView viewProductDetails(@RequestParam("productId") int productId) {
        Products product = productService.getProductById(productId);
        
        if (product == null) {
            return new ModelAndView("error").addObject("message", "Product not found");
        }

        ModelAndView modelAndView = new ModelAndView("ViewProductDetails");
        modelAndView.addObject("product", product);

        // You can also add user reviews here, if available.
        // List<Review> reviews = reviewService.getReviewsByProductId(productId);
        // modelAndView.addObject("reviews", reviews);

        return modelAndView;
    }
	
}
