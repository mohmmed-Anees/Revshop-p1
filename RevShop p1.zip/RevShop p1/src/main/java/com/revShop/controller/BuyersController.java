package com.revShop.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.revShop.Util.PasswordUtil;
import com.revShop.entity.Buyer;
import com.revShop.entity.Products;
import com.revShop.service.BuyerService;
import com.revShop.service.EmailService;
import com.revShop.service.ProductService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/buyers")
public class BuyersController {
	
	@Autowired
	private BuyerService buyerService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private EmailService emailService;
	
	@GetMapping("/home")
    public ModelAndView Home(HttpSession session) {
		List<Products> productList = (List<Products>) session.getAttribute("products");
	    if (productList == null) {
	        productList = productService.getAllProducts(); 
	        session.setAttribute("products", productList);
	    }
	    
	    return new ModelAndView("Home");
    }
	
	@PostMapping("/register")
	public ModelAndView registerBuyer(Buyer buyer) {
	    
	    Optional<Buyer> existingBuyer = buyerService.findBuyerByEmail(buyer.getEmail());
	    
	    if (existingBuyer.isPresent()) {
	        
	        ModelAndView modelAndView = new ModelAndView("BuyerLogin");
	        modelAndView.addObject("error", "You are already registered. Please log in.");
	        return modelAndView;
	    }
	    
	    
	    buyerService.registerBuyer(buyer);
	    
	    
	    String subject = "Registration Successful";
	    String body = "Dear " + buyer.getBuyerName() + ",\n\nYou have successfully registered. You can now log in using your credentials.\n\nBest regards,\nRevShop Team";
	    emailService.sendEmail(buyer.getEmail(), subject, body);
	    
	    
	    return new ModelAndView("Success");
	}
	
	@GetMapping("/register")
	public ModelAndView showRegistrationForm() {
			
        return new ModelAndView("BuyerRegistration");  
    }

    @GetMapping("/{buyerId}")
    public Buyer getBuyerById(@PathVariable Integer buyerId) {
        Optional<Buyer> buyer = buyerService.getBuyerById(buyerId);
        return buyer.orElse(null);  
    }

    @GetMapping
    public List<Buyer> getAllBuyers() {
        return buyerService.getAllBuyers();
    }

    @PutMapping("/{buyerId}")
    public Buyer updateBuyer(@PathVariable Integer buyerId, @RequestBody Buyer buyer) {
        Optional<Buyer> existingBuyer = buyerService.getBuyerById(buyerId);
        if (existingBuyer.isPresent()) {
            buyer.setBuyerId(buyerId);
            return buyerService.updateBuyer(buyer);
        } else {
            return null;  
        }
    }

    @DeleteMapping("/{buyerId}")
    public String deleteBuyer(@PathVariable Integer buyerId) {
        Optional<Buyer> existingBuyer = buyerService.getBuyerById(buyerId);
        if (existingBuyer.isPresent()) {
            buyerService.deleteBuyer(buyerId);
            return "Buyer deleted successfully.";
        } else {
            return "Buyer not found.";
        }
    }

    @GetMapping("/email/{email}")
    public Buyer findBuyerByEmail(@PathVariable String email) {
        Optional<Buyer> buyer = buyerService.findBuyerByEmail(email);
        return buyer.orElse(null);  
    }
    
//    @PostMapping("/login")
//    public ModelAndView loginBuyer(@RequestParam String email, @RequestParam String password, HttpSession session) {
//        Optional<Buyer> buyer = buyerService.findBuyerByEmail(email);
//        
//        if (buyer.isPresent()) {
//            
//            String hashedInputPassword =  PasswordUtil.hashPassword(password);
//
//            
//            if (buyer.get().getPassword().equals(hashedInputPassword)) {
//            	session.setAttribute("loggedInBuyer", buyer.get());
//            	
//            	List<Products> productList = productService.getAllProducts(); 
//                session.setAttribute("products", productList);
//                
//                return new ModelAndView("Home");
//            }
//        }
//
//        ModelAndView modelAndView = new ModelAndView("BuyerLogin");
//        modelAndView.addObject("error", "Invalid email or password");
//        return modelAndView;
//    }
    
    @PostMapping("/login")
    public ModelAndView loginBuyer(@RequestParam String email, @RequestParam String password, HttpSession session) {
        System.out.println("Email provided: " + email); // Log email before search

        Optional<Buyer> buyer = buyerService.findBuyerByEmail(email);

        // Check if buyer is present
        if (buyer.isPresent()) {
            System.out.println("Buyer found: " + buyer.get()); 
            
           
            String hashedInputPassword = PasswordUtil.hashPassword(password);

            
            System.out.println("Hashed input password: " + hashedInputPassword);
            System.out.println("Stored hashed password: " + buyer.get().getPassword());

            if (buyer.get().getPassword().equals(hashedInputPassword)) {
                session.setAttribute("loggedInBuyer", buyer.get());

                List<Products> productList = productService.getAllProducts();
                session.setAttribute("products", productList);

                return new ModelAndView("Home");
            }
        }

        // Log error if buyer not found or password incorrect
        System.out.println("Invalid login attempt");

        ModelAndView modelAndView = new ModelAndView("BuyerLogin");
        modelAndView.addObject("error", "Invalid email or password");
        return modelAndView;
    }
    
    @GetMapping("/login")
    public ModelAndView loginBuyerFrom() {
    	return new ModelAndView("BuyerLogin");
    }
    
    @GetMapping("/logout")
    public ModelAndView logoutBuyer(HttpSession session) {
        
        session.invalidate();
        
        
        return new ModelAndView("redirect:/home");
    }
    
    
    @PostMapping("/forgot-password")
    public ModelAndView forgotPassword(@RequestParam("email") String email) {
        Optional<Buyer> buyerOptional = buyerService.findBuyerByEmail(email);
        
        if (buyerOptional.isPresent()) {
            
            String resetToken = PasswordUtil.generateResetToken();
            
            
            Buyer buyer = buyerOptional.get();
            buyer.setResetToken(resetToken);
            buyerService.updateBuyer(buyer);
            
            // Send reset email
            String resetLink = "http://localhost:8080/buyers/reset-password?token=" + resetToken;
            String subject = "Password Reset Request";
            String body = "Dear " + buyer.getBuyerName() + ",\n\nClick the link below to reset your password:\n" + resetLink;
            emailService.sendEmail(buyer.getEmail(), subject, body);
            
            return new ModelAndView("ForgetPasswordSuccess");
        } else {
            ModelAndView modelAndView = new ModelAndView("ForgetPassword");
            modelAndView.addObject("error", "Email not found.");
            return modelAndView;
        }
    }
    
    @GetMapping("/forgot-password")
    public ModelAndView forgetPassword() {
    	return new ModelAndView("ForgetPassword");
    }
    
    @GetMapping("/reset-password")
    public ModelAndView showResetPasswordForm(@RequestParam("token") String token) {
        Optional<Buyer> buyerOptional = buyerService.findByResetToken(token);
        
        if (buyerOptional.isPresent()) {
            ModelAndView modelAndView = new ModelAndView("ResetPassword");
            modelAndView.addObject("token", token);  
            return modelAndView;
        } else {
            ModelAndView modelAndView = new ModelAndView("ForgetPassword");
            modelAndView.addObject("error", "Invalid token.");
            return modelAndView;
        }
    }
    
    @PostMapping("/reset-password")
    public ModelAndView resetPassword(@RequestParam("token") String token, @RequestParam("password") String password) {
        Optional<Buyer> buyerOptional = buyerService.findByResetToken(token);
        
        if (buyerOptional.isPresent()) {
            Buyer buyer = buyerOptional.get();
            
            
            String hashedPassword = PasswordUtil.hashPassword(password);
            buyer.setPassword(hashedPassword);
            buyer.setResetToken(null);  
            buyerService.updateBuyer(buyer);
            
            return new ModelAndView("PasswordResetSuccess");
        } else {
            ModelAndView modelAndView = new ModelAndView("ResetPassword");
            modelAndView.addObject("error", "Invalid token.");
            return modelAndView;
        }
    }
    
//    @PutMapping("/reset-password")
//    public ModelAndView resetPassword(@RequestParam("token") String token, @RequestParam("password") String password) {
//        System.out.println("Reset token: " + token); // Log token
//
//        Optional<Buyer> buyerOptional = buyerService.findByResetToken(token);
//
//        if (buyerOptional.isPresent()) {
//            Buyer buyer = buyerOptional.get();
//            System.out.println("Buyer found for token: " + buyer); // Log buyer found by token
//            
//            String hashedPassword = PasswordUtil.hashPassword(password);
//            System.out.println("New hashed password: " + hashedPassword); // Log new hashed password
//            
//            buyer.setPassword(hashedPassword);
//            buyer.setResetToken(null);  // Clear reset token
//            buyerService.updateBuyer(buyer); // Update buyer in DB
//            
//            // Confirm update
//            Optional<Buyer> updatedBuyer = buyerService.findBuyerByEmail(buyer.getEmail());
//            System.out.println("Updated stored hashed password: " + updatedBuyer.get().getPassword()); // Log updated password
//
//            System.out.println("Password reset successful");
//            return new ModelAndView("PasswordResetSuccess");
//        } else {
//            System.out.println("Invalid token provided"); // Log if invalid token
//
//            ModelAndView modelAndView = new ModelAndView("ResetPassword");
//            modelAndView.addObject("error", "Invalid token.");
//            return modelAndView;
//        }
//    }




	
}


