package com.revShop.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.revShop.Util.PasswordUtil;
import com.revShop.entity.Products;
import com.revShop.entity.Seller;
import com.revShop.service.EmailService;
import com.revShop.service.ProductService;
import com.revShop.service.SellerService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/sellers")
public class SellerController {
	
	@Autowired
	private SellerService sellerService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
    private EmailService emailService;

    
    @PostMapping("/register")
    public ModelAndView registerSeller(Seller seller) {
        Optional<Seller> existingSeller = sellerService.findSellerByEmail(seller.getEmail());

        if (existingSeller.isPresent()) {
            ModelAndView modelAndView = new ModelAndView("SellerLogin");
            modelAndView.addObject("error", "You are already registered. Please log in.");
            return modelAndView;
        }

        sellerService.registerSeller(seller);

        
        String subject = "Registration Successful";
        String body = "Dear " + seller.getSellerName() + ",\n\nYou have successfully registered as a seller. You can now log in using your credentials.\n\nBest regards,\nRevShop Team";
        emailService.sendEmail(seller.getEmail(), subject, body);

        return new ModelAndView("Success");
    }

    
    @GetMapping("/register")
    public ModelAndView showRegistrationForm() {
        return new ModelAndView("SellerRegistration");
    }

    
    @GetMapping("/{sellerId}")
    public Seller getSellerById(@PathVariable Integer sellerId) {
        Optional<Seller> seller = sellerService.getSellerById(sellerId);
        return seller.orElse(null);
    }

    
    @GetMapping
    public List<Seller> getAllSellers() {
        return sellerService.getAllSellers();
    }

    
    @PutMapping("/{sellerId}")
    public Seller updateSeller(@PathVariable Integer sellerId, @RequestBody Seller seller) {
        Optional<Seller> existingSeller = sellerService.getSellerById(sellerId);
        if (existingSeller.isPresent()) {
            seller.setSellerId(sellerId);
            return sellerService.updateSeller(seller);
        } else {
            return null;
        }
    }

    
    @DeleteMapping("/{sellerId}")
    public String deleteSeller(@PathVariable Integer sellerId) {
        Optional<Seller> existingSeller = sellerService.getSellerById(sellerId);
        if (existingSeller.isPresent()) {
            sellerService.deleteSeller(sellerId);
            return "Seller deleted successfully.";
        } else {
            return "Seller not found.";
        }
    }

    
    @GetMapping("/email/{email}")
    public Seller findSellerByEmail(@PathVariable String email) {
        Optional<Seller> seller = sellerService.findSellerByEmail(email);
        return seller.orElse(null);
    }

    
    @PostMapping("/login")
    public ModelAndView loginSeller(@RequestParam String email, @RequestParam String password, HttpSession session) {
    	Optional<Seller> seller = sellerService.findSellerByEmail(email);

        if (seller.isPresent()) {
            String hashedInputPassword = PasswordUtil.hashPassword(password);

            if (seller.get().getPassword().equals(hashedInputPassword)) {
                
                session.setAttribute("loggedSeller", seller.get());
                return new ModelAndView("redirect:/sellerhome");
            }
        }

        ModelAndView modelAndView = new ModelAndView("SellerLogin");
        modelAndView.addObject("error", "Invalid email or password");
        return modelAndView;
    }

    
    @GetMapping("/login")
    public ModelAndView loginSellerForm() {
        return new ModelAndView("SellerLogin");
    }
    
    @PostMapping("/products/add")
    public ModelAndView addProduct(
            @RequestParam("imageFile") MultipartFile imageFile,
            @ModelAttribute Products products, HttpSession session) {


        Seller seller = (Seller) session.getAttribute("loggedSeller");
        if (seller == null) {
            ModelAndView modelAndView = new ModelAndView("Error");
            modelAndView.addObject("error", "Seller not logged in");
            return modelAndView;
        }

        products.setSeller(seller);

        try {
            productService.addProduct(products, seller.getSellerId(), imageFile);
        } catch (IOException e) {
            ModelAndView modelAndView = new ModelAndView("Error");
            modelAndView.addObject("error", "Failed to upload image");
            return modelAndView;
        }

        return new ModelAndView("Success");
    }
    
    @GetMapping("/products/add")
    public ModelAndView addProductForm() {
        return new ModelAndView("addProducts");
    }

}
