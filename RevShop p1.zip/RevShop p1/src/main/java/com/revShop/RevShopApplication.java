package com.revShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevShopApplication.class, args);
	}

}
