package com.revShop.entity;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;

import com.revShop.Util.PasswordUtil;

import jakarta.persistence.*;

@Entity
@Table(name = "seller")
public class Seller {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int sellerId;

    @Column(nullable = false, length = 100)
    private String sellerName;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(length = 50)
    private String businessType;

    @Column(length = 500)
    private String businessDetails;

    @Column(nullable = false, unique = true)
    private long phoneNumber;

    @Column(length = 255)
    private String address;
    
    @Column(nullable = false)
    private String city;
	 
	 @Column(nullable = false)
	 private String state;
	 
	 @Column(nullable = false)
	 private String pincode; 

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Timestamp createdAt;
    
    public Seller() {
    	
    }
    
	public Seller(int sellerId, String sellerName, String email, String password, String businessType,
			String businessDetails, long phoneNumber, String address, String city, String state, String pincode,
			Timestamp createdAt) {
		super();
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.email = email;
		this.password = password;
		this.businessType = businessType;
		this.businessDetails = businessDetails;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.createdAt = createdAt;
	}



	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = PasswordUtil.hashPassword(password);
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getBusinessDetails() {
		return businessDetails;
	}

	public void setBusinessDetails(String businessDetails) {
		this.businessDetails = businessDetails;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getPincode() {
		return pincode;
	}



	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	
    
    
}
