package com.revShop.entity;

import java.sql.Timestamp;


import org.hibernate.annotations.CreationTimestamp;

import com.revShop.Util.PasswordUtil;

import jakarta.persistence.*;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;



@Entity
@Table(name = "buyer", uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
public class Buyer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int buyerId;
	
	@Column(nullable = false)
	private String buyerName;
	
	@Column(nullable = false,unique = true)
	private String email;
	
	@Column(nullable = false)
	private String password;
	
	
	 @Column(nullable = false)
	 private long phoneNumber;

	 @Column(nullable = false)
	 private String address;
	 
	 @Column(nullable = false)
	 private String city;
	 
	 @Column(nullable = false)
	 private String state;
	 
	 @Column(nullable = false)
	 private String pincode; 

	 @CreationTimestamp
	 @Column(nullable = false, updatable = false)
	 private Timestamp createdAt;
	 
	 private String resetToken;
	 
	public Buyer() {
		super();
	}

	public Buyer(int buyerId, String buyerName, String email, String password, long phoneNumber, String address,
			String city, String state, String pincode, Timestamp createdAt,String resetToken) {
		super();
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.email = email;
		this.password = password;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.createdAt = createdAt;
		this.resetToken = resetToken;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = PasswordUtil.hashPassword(password);
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public String getResetToken() {
		return resetToken;
	}

	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}
	
	 
}
