package com.revShop.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revShop.Util.PasswordUtil;
import com.revShop.entity.Buyer;
import com.revShop.repository.BuyerRepositroy;

import jakarta.persistence.EntityManager;

@Service
public class BuyerService {
	
	@Autowired
	private BuyerRepositroy buyerRepository;
	
	public Buyer registerBuyer(Buyer buyer) {
        return buyerRepository.save(buyer); 
    }

    
    public Optional<Buyer> getBuyerById(Integer buyerId) {
        return buyerRepository.findById(buyerId);
    }

    
    public List<Buyer> getAllBuyers() {
        return buyerRepository.findAll();
    }

    
    public Buyer updateBuyer(Buyer buyer) {
        return buyerRepository.save(buyer); 
    }

    
    public void deleteBuyer(Integer buyerId) {
        buyerRepository.deleteById(buyerId);
    }
    
    
    public Optional<Buyer> findBuyerByEmail(String email) {
        System.out.println("Searching for buyer with email: " + email); // Log the query
        Optional<Buyer> buyer = buyerRepository.findByEmail(email); // Assuming JPA repository
        System.out.println("Query result: " + buyer); // Log result
        return buyer; // Ensure proper return statement
    }


    
//    public Optional<Buyer> findBuyerByEmail(String email) {
//        Buyer buyer = buyerRepository.findByEmail(email);
//        return Optional.ofNullable(buyer);
//    }
    

    
    public boolean existsByEmail(String email) {
        return buyerRepository.findByEmail(email) != null;
    }
    
    public Optional<Buyer> findByResetToken(String resetToken) {
        return buyerRepository.findByResetToken(resetToken);
    }
    
}
