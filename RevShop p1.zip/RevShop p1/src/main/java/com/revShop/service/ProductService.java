package com.revShop.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.revShop.entity.Products;
import com.revShop.entity.Seller;
import com.revShop.repository.ProductRepository;
import com.revShop.repository.SellerRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private SellerRepository sellerRepository;
	
	 public Products addProduct(Products product, int sellerId, MultipartFile imageFile) throws IOException {
	        
	        Seller seller = sellerRepository.findById(sellerId)
	            .orElseThrow(() -> new IllegalArgumentException("Invalid seller ID"));

	        
	        product.setSeller(seller);

	        
	        if (imageFile != null && !imageFile.isEmpty()) {
	            String contentType = imageFile.getContentType();
	            if (contentType.equals("image/jpeg") || contentType.equals("image/png")) {
	                product.setImage(imageFile.getBytes());
	            } else {
	                throw new IllegalArgumentException("Only JPEG and PNG images are supported");
	            }
	        }

	        
	        return productRepository.save(product);
	    }
	 	
	 public List<Products> getAllProducts() {
	        return productRepository.findAll();  
	  }
	 
	 public List<String> getAllCategories() {
	        return productRepository.findAllDistinctCategories();
	    }

	    
	  public List<Products> getProductsByCategory(String category) {
	        return productRepository.findByCategory(category);  
	   }
	  
	  public Products getProductById(int productId){
		  return productRepository.findById(productId).orElse(null);
	  }
	
}
