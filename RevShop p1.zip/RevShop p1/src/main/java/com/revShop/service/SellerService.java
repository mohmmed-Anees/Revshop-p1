package com.revShop.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revShop.entity.Seller;
import com.revShop.repository.SellerRepository;

@Service
public class SellerService {
	
	@Autowired
	private SellerRepository sellerRepository;
	
	public Seller registerSeller(Seller seller) {
        return sellerRepository.save(seller); 
    }

    
    public Optional<Seller> getSellerById(Integer sellerId) {
        return sellerRepository.findById(sellerId);
    }

    
    public List<Seller> getAllSellers() {
        return sellerRepository.findAll();
    }

    
    public Seller updateSeller(Seller seller) {
        return sellerRepository.save(seller); 
    }

    
    public void deleteSeller(Integer sellerId) {
        sellerRepository.deleteById(sellerId);
    }

    
    public Optional<Seller> findSellerByEmail(String email) {
        Seller seller = sellerRepository.findByEmail(email);
        return Optional.ofNullable(seller);
    }

    
    public boolean existsByEmail(String email) {
        return sellerRepository.findByEmail(email) != null;
    }
	
}
