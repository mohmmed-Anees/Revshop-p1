package com.revShop.service;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name= "cart_items")

public class CartItems {

	
}
