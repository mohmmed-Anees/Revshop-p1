package com.revShop.service;

import org.springframework.stereotype.Service;

import com.revShop.entity.Cart;

@Service
public interface CartService {
    Cart addProductToCart(Integer userId, Integer productId, Integer quantity);
}
