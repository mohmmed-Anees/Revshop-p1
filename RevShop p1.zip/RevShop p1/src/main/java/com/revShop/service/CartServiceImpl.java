package com.revShop.service;


import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revShop.entity.Buyer;
import com.revShop.entity.Cart;
import com.revShop.entity.Products;
import com.revShop.repository.BuyerRepositroy;
import com.revShop.repository.CartRepository;
import com.revShop.repository.ProductRepository;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private BuyerRepositroy userRepository;

    @Override
    public Cart addProductToCart(Integer userId, Integer productId, Integer quantity) {
        // Fetch the user and product from the database
        Buyer user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Products product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Check if the user already has this product in their cart
        Optional<Cart> existingCartOpt = cartRepository.findByBuyerandproduct(userId, productId);

        Cart cart;
        if (existingCartOpt.isPresent()) {
            // If the product is already in the cart, update the quantity
            cart = existingCartOpt.get();
            cart.setQuantity(cart.getQuantity() + quantity);
        } else {
            // Otherwise, create a new cart item
            cart = new Cart();
            cart.setUser(user);
            cart.setProduct(product);
            cart.setQuantity(quantity);
        }
        
        BigDecimal price = product.getPrice();
        int quant = cart.getQuantity();

        // Calculate total price (using BigDecimal for precise calculations)
        BigDecimal totalPrice = price.multiply(BigDecimal.valueOf(quant));
        cart.setTotalPrice(totalPrice.doubleValue());


        // Save the updated cart back to the database
        return cartRepository.save(cart);
    }
}
